package com.anthonyeden.jtop;

public class ProcessField{

	public ProcessField(String name, Class type, String value){
		this.name = name;
		this.type = type;
		this.value = value;
	}

	public String getName(){
		return name;
	}
	
	public Class getType(){
		return type;
	}
	
	public Object getValue(){
		return value;
	}
	
	private String name;
	private Class type;
	private Object value;

}