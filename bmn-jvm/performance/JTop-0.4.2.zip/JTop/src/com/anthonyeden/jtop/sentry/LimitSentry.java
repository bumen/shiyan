/*-- 

 Copyright (C) 2000 Anthony Eden.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The names "J/Top" and "JTop" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact me@anthonyeden.com.
 
 4. Products derived from this software may not be called "J/Top" or "JTop", nor
    may "J/Top" or "JTop" appear in their name, without prior written permission
    from Anthony Eden (me@anthonyeden.com).
 
 In addition, I request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed by the
      Anthony Eden (http://www.anthonyeden.com/)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, 
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 POSSIBILITY OF SUCH DAMAGE.

 For more information on J/Top, please see <http://www.anthonyeden.com/projects/jtop>.
 
 */

package com.anthonyeden.jtop.sentry;

import java.awt.Component;
import java.util.*;
import org.jdom.*;
import com.anthonyeden.jtop.JTop;
import com.anthonyeden.jtop.Host;
import com.anthonyeden.jtop.Process;

public class LimitSentry extends AbstractSentry{
	
	public LimitSentry(){
		
	}
	
	public String getField(){
		return field;
	}
	
	public void setField(String field){
		String oldField = this.field;
		if(oldField == field){
			return;
		}
		
		if((oldField == null && field != null) ||
		   (field == null && oldField != null) || 
		   (!oldField.equals(field)))
		{
			// add vetoable here later
			this.field = field;
			getPropertyChangeSupport().firePropertyChange("field", oldField, field);
			host.setModified(true);
		}
	}
	
	public float getLimit(){
		return limit;
	}
	
	public void setLimit(float limit){
		float oldLimit = this.limit;
		if(oldLimit != limit){
			this.limit = limit;
			getPropertyChangeSupport().firePropertyChange("limit", new Float(oldLimit), 
				new Float(limit));
			host.setModified(true);
		}
	}
	
	public void setLimit(String limit){
		setLimit(Float.parseFloat(limit));
	}
	
	public Editor getEditor(){
		if(editor == null){
			editor = new LimitSentryEditor(this);
		}
		return editor;
	}
	
	public boolean test(){
		setState(TESTING);
		boolean passed = true;
		Vector processes;
		synchronized(this){
			processes = (Vector)(getHost().getProcesses()).clone();
		}
		
		String fieldName = getField();
		Enumeration enum = processes.elements();
		while(enum.hasMoreElements()){
			try{
				Process process = (Process)enum.nextElement();
				Object value = process.getField(fieldName);
				
				if(!(value instanceof Number)){
					throw new Exception("Tested value is not a number");
				}
				
				float current = ((Number)value).floatValue();
				
				if(current > limit){
					sendNotification();
					setState(FAILED);
					passed = false;
				}
			} catch(Exception e){
				JTop.error(e);
			}
		}
		
		if(passed){
			setState(PASSED);
		}
		
		return passed;
	}
	
	public void readConfiguration(Element element){
		setField(element.getChildTextTrim("field"));
		setLimit(element.getChildTextTrim("limit"));
	}
	
	public void writeConfiguration(Element element){
		element.removeChildren();
		
		Element fieldElement = new Element("field");
		fieldElement.addContent(getField());
		element.addContent(fieldElement);
		
		Element limitElement = new Element("limit");
		limitElement.addContent(Float.toString(getLimit()));
		element.addContent(limitElement);
	}
	
	private String field;
	private float limit;

	private LimitSentryEditor editor;

}