/*-- 

 Copyright (C) 2000 Anthony Eden.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The names "J/Top" and "JTop" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact me@anthonyeden.com.
 
 4. Products derived from this software may not be called "J/Top" or "JTop", nor
    may "J/Top" or "JTop" appear in their name, without prior written permission
    from Anthony Eden (me@anthonyeden.com).
 
 In addition, I request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed by the
      Anthony Eden (http://www.anthonyeden.com/)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, 
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 POSSIBILITY OF SUCH DAMAGE.

 For more information on J/Top, please see <http://www.anthonyeden.com/projects/jtop>.
 
 */

package com.anthonyeden.jtop.sentry;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import com.anthonyeden.jtop.*;

public class SentryNotifiersPanel extends JPanel{

	public SentryNotifiersPanel(Sentry sentry){
		this.sentry = sentry;
		init();
	}
	
	protected void applyNotifier(){
		Notifier notifier = (Notifier)availableList.getSelectedValue();
		if(notifier != null){
			sentry.addNotifier(notifier);
			reloadLists();
		}
	}
	
	protected void removeNotifier(){
		Notifier notifier = (Notifier)appliedList.getSelectedValue();
		if(notifier != null){
			sentry.removeNotifier(notifier);
			reloadLists();
		}
	}
	
	protected void reloadLists(){
		Vector notifiers = sentry.getNotifiers();
		availableFilter.filter(notifiers);
		appliedList.setListData(notifiers);
	}
	
	private void init(){
		GridBagLayout gbl = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();
		setLayout(gbl);
		
		gbc.insets = new Insets(1, 1, 1, 1);
		gbc.anchor = GridBagConstraints.NORTH;
		
		availableFilter = new ListFilter(JTop.getNotifiers());
		availableList = new JList(availableFilter);
		availableList.setFixedCellWidth(180);
		availableList.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent evt){
				if(evt.getClickCount() >= 2){
					applyNotifier();
				}
			}
		});
		JScrollPane availableScrollPane = new JScrollPane(availableList);
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.fill = GridBagConstraints.BOTH;
		gbc.gridwidth = 1;
		gbl.setConstraints(availableScrollPane, gbc);
		add(availableScrollPane);
		
		JPanel buttonPanel = createButtonPanel();
		gbc.weightx = 0;
		gbl.setConstraints(buttonPanel, gbc);
		add(buttonPanel);
		
		appliedList = new JList(sentry.getNotifiers());
		appliedList.setFixedCellWidth(180);
		appliedList.addMouseListener(new MouseAdapter(){
			public void mouseReleased(MouseEvent evt){
				removeNotifier();
			}
		});
		JScrollPane appliedScrollPane = new JScrollPane(appliedList);
		gbc.weightx = 1;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbl.setConstraints(appliedScrollPane, gbc);
		add(appliedScrollPane);
	}
	
	private JPanel createButtonPanel(){
		JPanel panel = new JPanel();
		
		GridBagLayout gbl = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();
		panel.setLayout(gbl);
		
		gbc.insets = new Insets(1, 1, 1, 1);
		gbc.anchor = GridBagConstraints.NORTH;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.weightx = 1;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		
		addNotifierButton = new JButton("Add");
		addNotifierButton.setMnemonic('a');
		addNotifierButton.setToolTipText("Add a notifier to the sentry");
		addNotifierButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent evt){
				applyNotifier();
			}
		});
		gbl.setConstraints(addNotifierButton, gbc);
		panel.add(addNotifierButton);
		
		removeNotifierButton = new JButton("Remove");
		removeNotifierButton.setMnemonic('r');
		removeNotifierButton.setToolTipText("Remove a notifier from the sentry");
		removeNotifierButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent evt){
				removeNotifier();
			}
		});
		gbl.setConstraints(removeNotifierButton, gbc);
		gbc.weighty = 1;
		panel.add(removeNotifierButton);
		
		return panel;
	}
	
	private Sentry sentry;
	
	private ListFilter availableFilter;
	private JList availableList;
	private JList appliedList;
	private JButton addNotifierButton;
	private JButton removeNotifierButton;

}