/*-- 

 Copyright (C) 2000 Anthony Eden.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The names "J/Top" and "JTop" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact me@anthonyeden.com.
 
 4. Products derived from this software may not be called "J/Top" or "JTop", nor
    may "J/Top" or "JTop" appear in their name, without prior written permission
    from Anthony Eden (me@anthonyeden.com).
 
 In addition, I request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed by the
      Anthony Eden (http://www.anthonyeden.com/)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, 
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 POSSIBILITY OF SUCH DAMAGE.

 For more information on J/Top, please see <http://www.anthonyeden.com/projects/jtop>.
 
 */

package com.anthonyeden.jtop;

import java.util.Vector;
import javax.swing.*;
import javax.swing.event.*;

public class ListFilter extends ListMap{

	public ListFilter(){
		indexes = new int[0];
	}
	
	public ListFilter(ListModel model){
		setListModel(model);
	}
	
	public void setListModel(ListModel model){
		super.setModel(model);
		filter();
	}
	
	public synchronized void filter(){
		tempIndexes.removeAllElements();
		int size = model.getSize();
		Vector values = getValues();
		TOP_LOOP: for(int i = 0; i < size; i++){
			Object value = model.getElementAt(i);
			//System.out.println("Checking element " + value);
			for(int j = 0, valuesSize = values.size(); j < valuesSize; j++){
				if(values.elementAt(j).equals(value)){
					continue TOP_LOOP;
				}
			}
			tempIndexes.addElement(new Integer(i));
		}
		
		indexes = new int[tempIndexes.size()];
		for(int i = 0; i < indexes.length; i++){
			indexes[i] = ((Integer)tempIndexes.elementAt(i)).intValue();
		}
	}
	
	public void intervalAdded(ListDataEvent evt){
		filter();
		super.intervalAdded(evt);
	}
	
	public void intervalRemoved(ListDataEvent evt){
		filter();
		super.intervalRemoved(evt);
	}
	
	public void contentsChanged(ListDataEvent evt){
		filter();
		super.contentsChanged(evt);
	}
	
	public int getSize(){
		return indexes.length;
	}
	
	public Object getElementAt(int index){
		return model.getElementAt(indexes[index]);
	}
	
	public void filter(Object value){
		Vector values = new Vector();
		values.addElement(value);
		filter(values);
	}
	
	public void filter(Object[] values){
		Vector valuesVector = new Vector();
		for(int i = 0; i < values.length; i++){
			valuesVector.addElement(values[i]);
		}
		filter(valuesVector);
	}
	
	public void filter(Vector values){
		this.values = values;
		filter();
		super.contentsChanged(new ListDataEvent(this, ListDataEvent.CONTENTS_CHANGED, 
			0, indexes.length));
	}
	
	public Vector getValues(){
		if(values == null){
			values = new Vector();
		}
		return values;
	}
	
	private Vector tempIndexes = new Vector();
	private Vector values;
	private int[] indexes;

}