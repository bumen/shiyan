/*-- 

 Copyright (C) 2000 Anthony Eden.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The names "J/Top" and "JTop" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact me@anthonyeden.com.
 
 4. Products derived from this software may not be called "J/Top" or "JTop", nor
    may "J/Top" or "JTop" appear in their name, without prior written permission
    from Anthony Eden (me@anthonyeden.com).
 
 In addition, I request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed by the
      Anthony Eden (http://www.anthonyeden.com/)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, 
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 POSSIBILITY OF SUCH DAMAGE.

 For more information on J/Top, please see <http://www.anthonyeden.com/projects/jtop>.
 
 */

package com.anthonyeden.jtop;

import java.util.Vector;
import javax.swing.event.TableModelEvent;
import javax.swing.table.TableModel;

/** A filter for TableModels.  The filter has a model (conforming to TableModel)
	and itself implements TableModel.
	
	@author Anthony Eden
*/

public class TableFilter extends TableMap{
	
	public TableFilter(){
		indexes = new int[0];
	}
	
	public TableFilter(TableModel model){
		setTableModel(model);
	}

	public void setTableModel(TableModel model){
		super.setModel(model);
		filter();
	}
	
	public synchronized void filter(){
		tempIndexes.removeAllElements();
		int rows = model.getRowCount();
		for(int row = 0; row < rows; row++){
			if(column < 0){
				tempIndexes.addElement(new Integer(row));
			} else {
				Object value = model.getValueAt(row, column);
				for(int i = 0; i < values.length; i++){
					if(values[i].equals(value)){
						tempIndexes.addElement(new Integer(row));
					}
				}
			}
		}
		
		indexes = new int[tempIndexes.size()];
		for(int i = 0; i < indexes.length; i++){
			indexes[i] = ((Integer)tempIndexes.elementAt(i)).intValue();
		}
	}
	
	public void tableChanged(TableModelEvent evt){
		filter();
		super.tableChanged(evt);
	}
	
	public int getRowCount(){
		return indexes.length;
	}
	
	public Object getValueAt(int row, int column){
		return model.getValueAt(indexes[row], column);
	}
	
	public void setValueAt(Object newValue, int row, int column){
		model.setValueAt(newValue, indexes[row], column);
	}
	
	public void filter(int column, Object value){
		Object[] values = new Object[1];
		values[0] = value;
		filter(column, values);
	}
	
	public void filter(int column, Object[] values){
		this.column = column;
		this.values = values;
		filter();
		super.tableChanged(new TableModelEvent(this));
	}
	
	public int getColumn(){
		return column;
	}
	
	public Object[] getValues(){
		return values;
	}
	
	private int[] indexes;
	private Vector tempIndexes = new Vector();
	private int column = -1;
	private Object[] values;

}