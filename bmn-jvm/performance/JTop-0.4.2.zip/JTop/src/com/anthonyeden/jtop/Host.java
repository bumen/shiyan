/*-- 

 Copyright (C) 2000 Anthony Eden.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The names "J/Top" and "JTop" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact me@anthonyeden.com.
 
 4. Products derived from this software may not be called "J/Top" or "JTop", nor
    may "J/Top" or "JTop" appear in their name, without prior written permission
    from Anthony Eden (me@anthonyeden.com).
 
 In addition, I request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed by the
      Anthony Eden (http://www.anthonyeden.com/)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, 
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 POSSIBILITY OF SUCH DAMAGE.

 For more information on J/Top, please see <http://www.anthonyeden.com/projects/jtop>.
 
 */

package com.anthonyeden.jtop;

import java.io.*;
import java.net.*;
import java.util.*;
import com.anthonyeden.jtop.util.*;
import com.anthonyeden.jtop.event.*;
import com.anthonyeden.jtop.sentry.*;

/** The Host class represents a single Host to monitor.  Each Host acts
	on its own to retrieve the current 'top' values.
	
	<p>The Host class is abstract and should be overridden by concrete
	subclasses which will handle actual parsing of the data retrieved from
	the jtopd daemon.</p>

	@author Anthony Eden
*/

public abstract class Host implements Runnable{

	/** Sets the hostname to the value of <code>DEFAULT_HOSTNAME</code> 
		and the port to the value of <code>DEFAULT_PORT</code>.
	*/

	public Host(){
		this(DEFAULT_HOSTNAME);
	}
	
	/** Sets the hostname to the given hostname and the port to the value
		of <code>DEFAULT_PORT</code>.
		
		@param hostname The hostname (or IP address)
	*/
	
	public Host(String hostname){
		this(hostname, DEFAULT_PORT);
	}
	
	/** Sets the hostname and port to their given values.
	
		@param hostname The hostname (or IP addres)
		@param port The port
	*/
	
	public Host(String hostname, int port){
		setHostname(hostname);
		setPort(port);
	}
	
	/** Get an array of field names in order as they should appear in the
		display table.
		
		@return An array of field names
	*/
	
	public abstract String[] getFieldNames();
	
	/** Get an array of display names in order as they should appear in the
		display table.  Each display name should correspond to the field
		name which will be displayed.
		
		@return An array of display names
	*/
	
	public abstract String[] getDisplayNames();
	
	/** Get the display name for the given field name.
	
		@return The display name for the given field name
	*/	
	
	public abstract String getDisplayName(String fieldName);
	
	/** Get an array of field classes.
	
		@return An array of field classes
	*/
	
	public abstract Class[] getFieldClasses();
	public abstract Class getFieldClass(String fieldName);
	
	/** Create a Process which is usable in this Host.
	
		@return A Process
	*/
	
	public abstract Process createProcess();
	
	/** Poll the host. */
	
	public abstract void poll();
	
	/** Get an object representing the current System memory usage.
	
		@return The current system memory usage
	*/
	
	public abstract Memory getMemory();
	
	public Vector getProcesses(){
		if(processes == null){
			processes = new Vector();
		}
		return processes;
	}
	
	/** Get the display name for this host.  If the display name has not been
		set or the display name is an empty String, then the hostname will be 
		used by default.
		
		@return The display name
	*/
	
	public String getDisplayName(){
		if(displayName == null || displayName.trim().equals("")){
			return getHostname();
		}
		return displayName;
	}
	
	/** Set the display name for this host.
	
		@param displayName The display name
	*/
	
	public void setDisplayName(String displayName){
		this.displayName = displayName;
		modified = true;
	}
	
	/** Get the target machine's hostname.  This may be either a domain name
		or an IP address.
		
		@return The target machine's hostname
	*/

	public String getHostname(){
		if(hostname == null){
			hostname = DEFAULT_HOSTNAME;
		}
		return hostname;
	}
	
	/** Set the target machine's hostname.  This may be either a domain name
		or an IP address.
		
		@param hostname The target machine's hostname
	*/
	
	public void setHostname(String hostname){
		this.hostname = hostname;
		modified = true;
	}
	
	/** Get the port that the host should connect to for retreiving Top
		data.
		
		@return The port
	*/
	
	public int getPort(){
		return port;
	}
	
	/** Set the port that the host should connect to for retreiving Top
		data.
		
		@param port The port
	*/
	
	public void setPort(int port){
		this.port = port;
		modified = true;
	}
	
	/** Set the port that the host should connect to for retreiving Top
		data.  The given String will be converted to an integer.
		
		@param port The port
	*/
	
	public void setPort(String port){
		if(port != null){
			setPort(Integer.parseInt(port));
		}
	}
	
	/** Get the number of iterations which should be performed.
	
		@return The number of polling iterations
	*/
	
	public long getIterations(){
		return iterations;
	}
	
	/** Set the number of iterations which should be performed.  When the number
		of iterations is reached, the host will no longer poll its target machine.
		Use the constant <code>Host.INFINITY</code> (or any value less than 0)
		to poll indefinately.
	
		@param interations The number of iterations to poll
	*/
	
	public void setIterations(long iterations){
		this.iterations = iterations;
		modified = true;
	}
	
	/** Add the given HostListener.
	
		@param l The HostListener to add
	*/
	
	public void addHostListener(HostListener l){
		getHostListeners().addElement(l);
	}
	
	/** Remove the given HostListener.
	
		@param l The HostListener to remove
	*/
	
	public void removeHostListener(HostListener l){
		getHostListeners().removeElement(l);
	}
	
	/** Get the SentrySet containing all Sentries for the Host.  This method should 
		never return null.
	
		@return A SentrySet
	*/
	
	public SentrySet getSentries(){
		if(sentries == null){
			sentries = new SentrySet();
		}
		return sentries;
	}
	
	/** Add the given Sentry from this host's sentry list.
	
		@param sentry The Sentry to add
	*/
	
	public void addSentry(Sentry sentry){
		getSentries().add(sentry);
		modified = true;
	}
	
	/** Remove the given Sentry from this host's sentry list.
	
		@param sentry The Sentry to remove
	*/
	
	public void removeSentry(Sentry sentry){
		getSentries().remove(sentry);
		modified = true;
	}
	
	/** Return true if the Host has been modified.
	
		@return True if the Host was modified
	*/
	
	public boolean isModified(){
		return modified;
	}
	
	/** Set to true if the Host has been modified.
	
		@param modified True if the Host was modified
	*/
	
	public void setModified(boolean modified){
		this.modified = modified;
	}
	
	/** Run.  This method should not be called directly, rather a Thread
		should be created and then the <code>Thread.start()</code> method should be called.
	*/
	
	public void run(){
		long loopCount = 0;
		while(running){
			poll();
			test();
			
			loopCount++;
	
			if(iterations != INFINITY && loopCount >= iterations){
				stopPolling();
			}
			
			if(!running){
				return;
			}
			
			try{
				Thread.sleep(delay);
			} catch(InterruptedException e){
				
			}
		}
	}
	
	/** Test the state of the Host using the Host's Sentries. */
	
	public void test(){
		TestThread testThread = new TestThread(getSentries());
		testThread.start();
	}
	
	/** Start polling. */
	
	public void startPolling(){
		if(!running){
			running = true;
			thread = new Thread(this);
			thread.start();
		}
	}
	
	/** Stop polling. */
	
	public void stopPolling(){
		if(running){
			running = false;
			thread.interrupt();
		}
	}
	
	/** Return true if the Host is currently updating.
	
		@return True if the Host is updating
	*/
	
	public boolean isUpdating(){
		return updating;
	}
	
	/** Return the Host's display name. 
	
		@return The display name
	*/
	
	public String toString(){
		return getDisplayName();
	}
	
	// protected methods
	
	/** Set the processes for the host.
	
		@param process A Vector of Processes
	*/
	
	protected void setProcesses(Vector processes){
		this.processes = processes;
	}
	
	/** Get a Vector of HostListeners.  This method should never return null.
	
		@return A Vector of HostListeners
	*/
	
	protected Vector getHostListeners(){
		if(hostListeners == null){
			hostListeners = new Vector();
		}
		return hostListeners;
	}
	
	/** Fire a HostEvent. The HostEvent signifies that the host's process
		information has been updated.
	*/
	
	protected void fireHostEvent(){
		HostEvent evt = new HostEvent(this);
		Vector v;
		
		synchronized(this){
			v = (Vector)(getHostListeners().clone());
		}
		
		Enumeration l = v.elements();
		while(l.hasMoreElements()){
			((HostListener)l.nextElement()).responseReceived(evt);
		}
	}
	
	protected void finalize(){
		System.out.println("Finalized " + hashCode() + " [" + getClass() + "]");
	}
	
	/** Constant representing an infinate number of iterations. */
	
	public static final long INFINITY = -1;
	
	/** Constant representing the default hostname of <code>localhost</code>. */
	
	public static final String DEFAULT_HOSTNAME = "localhost";
	
	/** Constant representing the default port of <code>24090</code>. */
	
	public static final int DEFAULT_PORT = 24090;
	
	/** Constant representing the default delay of 5 seconds. */
	
	public static final int DEFAULT_DELAY = 5000;
	
	/** The current memory information for this host. */
	
	protected Memory memory;
	
	/** Running state flag. */
	
	protected boolean running = false;
	
	/** Update state flag. */
	
	protected boolean updating = false;
	
	/** Debug flag. */
	
	protected boolean debug = false;
	
	/** Modified flag. */
	
	protected boolean modified = false;

	private String displayName;
	private String hostname;
	private int port;
	private int delay= DEFAULT_DELAY;
	private Vector processes;
	
	private Vector hostListeners;
	private SentrySet sentries;
	
	private Thread thread;
	private long iterations = INFINITY;

}