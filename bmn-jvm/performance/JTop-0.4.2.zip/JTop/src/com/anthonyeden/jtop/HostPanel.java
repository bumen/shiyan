/*-- 

 Copyright (C) 2000 Anthony Eden.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The names "J/Top" and "JTop" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact me@anthonyeden.com.
 
 4. Products derived from this software may not be called "J/Top" or "JTop", nor
    may "J/Top" or "JTop" appear in their name, without prior written permission
    from Anthony Eden (me@anthonyeden.com).
 
 In addition, I request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed by the
      Anthony Eden (http://www.anthonyeden.com/)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, 
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 POSSIBILITY OF SUCH DAMAGE.

 For more information on J/Top, please see <http://www.anthonyeden.com/projects/jtop>.
 
 */

package com.anthonyeden.jtop;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class HostPanel extends JPanel{

	public HostPanel(){
		this(null);
	}
	
	public HostPanel(Host host){
		this.host = host;
		init();
		revert();
	}
	
	public Host getHost(){
		return host;
	}
	
	public void save(){
		try{	
			if(host == null){
				host = HostManager.createHost(hostTypeCombo.getSelectedItem().toString());
			}
		
			host.setDisplayName(displayNameField.getText().trim());
			host.setHostname(hostnameField.getText().trim());
			
			String portString = portField.getText().trim();
			if(!portString.equals("")){
				host.setPort(Integer.parseInt(portString));
			}
		} catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public void revert(){
		if(host != null){
			displayNameField.setText(host.getDisplayName());
			hostnameField.setText(host.getHostname());
			portField.setText(Integer.toString(host.getPort()));
		}
	}
	
	private void init(){
		GridBagLayout gbl = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();
		setLayout(gbl);
		
		gbc.insets = new Insets(1, 1, 1, 1);
		gbc.fill = GridBagConstraints.HORIZONTAL;
		
		hostTypeLabel = new JLabel("Type:");
		hostTypeLabel.setToolTipText("Select target host type");
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(hostTypeLabel, gbc);
		add(hostTypeLabel);
		
		hostTypeCombo = new JComboBox(HostManager.getNames());
		gbc.weightx = 1;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbl.setConstraints(hostTypeCombo, gbc);
		add(hostTypeCombo);
		
		displayNameLabel = new JLabel("Name:");
		displayNameLabel.setToolTipText("Display name");
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(displayNameLabel, gbc);
		add(displayNameLabel);
		
		displayNameField = new JTextField();
		displayNameField.setColumns(32);
		gbc.weightx = 1;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbl.setConstraints(displayNameField, gbc);
		add(displayNameField);
		
		hostnameLabel = new JLabel("Hostname:");
		hostnameLabel.setToolTipText("Target hostname or IP address");
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(hostnameLabel, gbc);
		add(hostnameLabel);
		
		hostnameField = new JTextField();
		hostnameField.setColumns(32);
		gbc.weightx = 1;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbl.setConstraints(hostnameField, gbc);
		add(hostnameField);
		
		portLabel = new JLabel("Port:");
		portLabel.setToolTipText("Target port");
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(portLabel, gbc);
		add(portLabel);
		
		portField = new JTextField();
		portField.setColumns(6);
		gbc.weightx = 1;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbl.setConstraints(portField, gbc);
		add(portField);
	}
	
	private Host host;
	
	private JLabel hostTypeLabel;
	private JComboBox hostTypeCombo;
	private JLabel displayNameLabel;
	private JTextField displayNameField;
	private JLabel hostnameLabel;
	private JTextField hostnameField;
	private JLabel portLabel;
	private JTextField portField;

}