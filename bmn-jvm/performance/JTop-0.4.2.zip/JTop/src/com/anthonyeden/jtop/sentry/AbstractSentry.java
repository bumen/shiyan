/*-- 

 Copyright (C) 2000 Anthony Eden.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The names "J/Top" and "JTop" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact me@anthonyeden.com.
 
 4. Products derived from this software may not be called "J/Top" or "JTop", nor
    may "J/Top" or "JTop" appear in their name, without prior written permission
    from Anthony Eden (me@anthonyeden.com).
 
 In addition, I request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed by the
      Anthony Eden (http://www.anthonyeden.com/)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, 
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 POSSIBILITY OF SUCH DAMAGE.

 For more information on J/Top, please see <http://www.anthonyeden.com/projects/jtop>.
 
 */

package com.anthonyeden.jtop.sentry;

import java.awt.Component;
import java.beans.*;
import java.util.*;
import com.anthonyeden.jtop.*;
import com.anthonyeden.jtop.event.*;

/** Basic implementation of standard Sentry functionality.

	@author Anthony Eden
*/

public abstract class AbstractSentry implements Sentry{

	public String getName(){
		if(name == null){
			name = "New Sentry";
		}
		return name;
	}
	
	public void setName(String name){
		this.name = name;
		host.setModified(true);
	}
	
	public Host getHost(){
		return host;
	}
	
	public void setHost(Host host){
		this.host = host;
	}

	public void addNotifier(Notifier notifier){
		getNotifiers().addElement(notifier);
		host.setModified(true);
	}
	
	public void removeNotifier(Notifier notifier){
		getNotifiers().removeElement(notifier);
		host.setModified(true);
	}
	
	/** Get the current state of the sentry.  Possible values are:
	
		<ul>
		<li>OK
		<li>FAILED
		<li>NOT_TESTED
		</ul>
		
		@return The state of the Sentry
	*/
	
	public int getState(){
		return state;
	}
	
	protected void setState(int state){
		this.state = state;
		fireSentryStateChanged();
	}
	
	public String toString(){
		return getName();
	}
	
	/** Get a Vector containing all registered notifiers.
	
		@return A Vector of Notifier objects
	*/
	
	public Vector getNotifiers(){
		if(notifiers == null){
			notifiers = new Vector();
		}
		return notifiers;
	}
	
	public void addPropertyChangeListener(PropertyChangeListener l){
		getPropertyChangeSupport().addPropertyChangeListener(l);
	}
	
	public void removePropertyChangeListener(PropertyChangeListener l){
		getPropertyChangeSupport().removePropertyChangeListener(l);
	}
	
	public void addSentryListener(SentryListener l){
		getSentryListeners().addElement(l);
	}
	
	public void removeSentryListener(SentryListener l){
		getSentryListeners().removeElement(l);
	}
	
	// protected methods
	
	protected PropertyChangeSupport getPropertyChangeSupport(){
		if(propertyChangeSupport == null){
			propertyChangeSupport = new PropertyChangeSupport(this);
		}
		return propertyChangeSupport;
	}
	
	protected Vector getSentryListeners(){
		if(sentryListeners == null){
			sentryListeners = new Vector();
		}
		return sentryListeners;
	}
	
	protected void fireSentryStateChanged(){
		SentryEvent evt = new SentryEvent(this);
		Vector v;
		
		synchronized(this){
			v = (Vector)(getSentryListeners().clone());
		}
		
		Enumeration l = v.elements();
		while(l.hasMoreElements()){
			((SentryListener)l.nextElement()).sentryStateChanged(evt);
		}
	}
	
	protected void sendNotification(){
		Vector v;
		
		synchronized(this){
			v = (Vector)(getNotifiers().clone());
		}
		
		Enumeration enum = v.elements();
		while(enum.hasMoreElements()){
			((Notifier)enum.nextElement()).notify(this);
		}
	}
	
	protected Host host;
	
	private DefaultSentryEditor editor;
	private String name;
	private int state = NOT_TESTED;
	private Vector notifiers;
	
	private PropertyChangeSupport propertyChangeSupport;
	private Vector sentryListeners;

}