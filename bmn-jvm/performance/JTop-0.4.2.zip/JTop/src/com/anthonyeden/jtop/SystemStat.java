package com.anthonyeden.jtop;

public abstract class SystemStat{



}