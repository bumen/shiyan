/*-- 

 Copyright (C) 2000 Anthony Eden.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The names "J/Top" and "JTop" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact me@anthonyeden.com.
 
 4. Products derived from this software may not be called "J/Top" or "JTop", nor
    may "J/Top" or "JTop" appear in their name, without prior written permission
    from Anthony Eden (me@anthonyeden.com).
 
 In addition, I request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed by the
      Anthony Eden (http://www.anthonyeden.com/)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, 
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 POSSIBILITY OF SUCH DAMAGE.

 For more information on J/Top, please see <http://www.anthonyeden.com/projects/jtop>.
 
 */

package com.anthonyeden.jtop;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class JTopMenuBar extends JMenuBar{

	public JTopMenuBar(JTop parent){
		this.parent = parent;
		init();
	}
	
	private void init(){
		Hashtable actions = parent.getActions();
		
		fileMenu = new JMenu("File");
		fileMenu.setMnemonic('f');
		
		Action newAction = (Action)actions.get("file.new");
		newMenuItem = fileMenu.add(newAction);
		newMenuItem.setMnemonic('n');
		newMenuItem.setAccelerator((KeyStroke)newAction.getValue("ACCELERATOR_KEY"));
		newMenuItem.setToolTipText((String)newAction.getValue(Action.SHORT_DESCRIPTION));
		
		Action openAction = (Action)actions.get("file.open");
		openMenuItem = fileMenu.add(openAction);
		openMenuItem.setMnemonic('o');
		openMenuItem.setAccelerator((KeyStroke)openAction.getValue("ACCELERATOR_KEY"));
		openMenuItem.setToolTipText((String)openAction.getValue(Action.SHORT_DESCRIPTION));
		
		fileMenu.addSeparator();
		
		Action saveAction = (Action)actions.get("file.save");
		saveMenuItem = fileMenu.add(saveAction);
		saveMenuItem.setMnemonic('s');
		saveMenuItem.setAccelerator((KeyStroke)saveAction.getValue("ACCELERATOR_KEY"));
		saveMenuItem.setToolTipText((String)saveAction.getValue(Action.SHORT_DESCRIPTION));
		
		saveAsMenuItem = fileMenu.add((Action)actions.get("file.saveAs"));
		saveAsMenuItem.setMnemonic('a');
		saveAsMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, Event.SHIFT_MASK + Event.CTRL_MASK));
		saveAsMenuItem.setToolTipText("Save the current configuration to a specified file");
		
		fileMenu.addSeparator();
		
		Action quitAction = (Action)actions.get("file.quit");
		quitMenuItem = fileMenu.add(quitAction);
		quitMenuItem.setMnemonic('q');
		quitMenuItem.setAccelerator((KeyStroke)quitAction.getValue("ACCELERATOR_KEY"));
		quitMenuItem.setToolTipText((String)quitAction.getValue(Action.SHORT_DESCRIPTION));
		
		add(fileMenu);
		
		editMenu = new JMenu("Edit");
		editMenu.setMnemonic('e');
		
		cutMenuItem = editMenu.add((Action)actions.get("edit.cut"));
		cutMenuItem.setMnemonic('u');
		cutMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, Event.CTRL_MASK));
		cutMenuItem.setToolTipText("Cut");
		
		copyMenuItem = editMenu.add((Action)actions.get("edit.copy"));
		copyMenuItem.setMnemonic('c');
		copyMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C, Event.CTRL_MASK));
		copyMenuItem.setToolTipText("Copy");
		
		pasteMenuItem = editMenu.add((Action)actions.get("edit.paste"));
		pasteMenuItem.setMnemonic('p');
		pasteMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V, Event.CTRL_MASK));
		pasteMenuItem.setToolTipText("Paste");
		
		editMenu.addSeparator();
		
		preferencesMenuItem = editMenu.add((Action)actions.get("edit.preferences"));
		preferencesMenuItem.setToolTipText("Application preferences");
		preferencesMenuItem.setEnabled(false);
		
		add(editMenu);
		
		hostMenu = new JMenu("Host");
		hostMenu.setMnemonic('h');
		
		addHostMenuItem = hostMenu.add((Action)actions.get("host.add"));
		addHostMenuItem.setMnemonic('a');
		addHostMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_H, Event.CTRL_MASK));
		addHostMenuItem.setToolTipText("Add a new host");
		
		configureHostMenuItem = hostMenu.add((Action)actions.get("host.configure"));
		configureHostMenuItem.setMnemonic('c');
		configureHostMenuItem.setToolTipText("Configure the selected host");
		
		removeHostMenuItem = hostMenu.add((Action)actions.get("host.remove"));
		removeHostMenuItem.setMnemonic('r');
		removeHostMenuItem.setToolTipText("Remove the selected host");
		
		hostMenu.addSeparator();
		
		//sentriesMenuItem = hostMenu.add((Action)actions.get("host.sentries"));
		//sentriesMenuItem.setMnemonic('s');
		//sentriesMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, Event.CTRL_MASK));
		//sentriesMenuItem.setToolTipText("View and edit the selected host sentries");
		
		sentriesMenu = new SentriesMenu(parent);
		hostMenu.add(sentriesMenu);
		
		notifiersMenuItem = hostMenu.add((Action)actions.get("host.notifiers"));
		notifiersMenuItem.setMnemonic('n');
		notifiersMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F, Event.CTRL_MASK));
		notifiersMenuItem.setToolTipText("View and edit notifiers");
		
		hostMenu.addSeparator();
		
		filterMenu = new FilterMenu(parent);
		filterMenu.setMnemonic('f');
		
		hostMenu.add(filterMenu);
		
		add(hostMenu);
		
		if(JTop.debuggingAllowed){
			System.out.println("Debugging allowed");
			debugMenu = new JMenu("Debug");
		
			debugCheck = new JCheckBox("Debug");
			debugCheck.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent evt){
					JTop.debug = debugCheck.isSelected();
				}
			});
			
			debugMenu.add(debugCheck);
			
			add(debugMenu);
		}
		
		helpMenu = new JMenu("Help");
		helpMenu.setMnemonic('h');
		
		usersGuideMenuItem = helpMenu.add((Action)actions.get("help.usersGuide"));
		usersGuideMenuItem.setToolTipText("Show the User's Guide");
		
		add(Box.createHorizontalGlue());
		add(helpMenu);
	}
	
	private JTop parent;
	
	private FilterMenu filterMenu;
	private JCheckBox debugCheck;
	
	private JMenu fileMenu;
	private JMenu editMenu;
	private JMenu hostMenu;
	private JMenu debugMenu;
	private JMenu helpMenu;
	
	private JMenuItem newMenuItem;
	private JMenuItem openMenuItem;
	private JMenuItem saveMenuItem;
	private JMenuItem saveAsMenuItem;
	private JMenuItem quitMenuItem;
	private JMenuItem cutMenuItem;
	private JMenuItem copyMenuItem;
	private JMenuItem pasteMenuItem;
	private JMenuItem preferencesMenuItem;
	private JMenuItem addHostMenuItem;
	private JMenuItem configureHostMenuItem;
	private JMenuItem removeHostMenuItem;
	private JMenuItem sentriesMenuItem;
	private JMenuItem notifiersMenuItem;
	private JMenuItem usersGuideMenuItem;
	
	private SentriesMenu sentriesMenu;

}