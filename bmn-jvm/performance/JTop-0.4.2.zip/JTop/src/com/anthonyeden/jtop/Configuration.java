/*-- 

 Copyright (C) 2000 Anthony Eden.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The names "J/Top" and "JTop" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact me@anthonyeden.com.
 
 4. Products derived from this software may not be called "J/Top" or "JTop", nor
    may "J/Top" or "JTop" appear in their name, without prior written permission
    from Anthony Eden (me@anthonyeden.com).
 
 In addition, I request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed by the
      Anthony Eden (http://www.anthonyeden.com/)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, 
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 POSSIBILITY OF SUCH DAMAGE.

 For more information on J/Top, please see <http://www.anthonyeden.com/projects/jtop>.
 
 */

package com.anthonyeden.jtop;

import java.io.*;
import java.util.*;
import org.jdom.*;
import org.jdom.input.*;
import org.jdom.output.*;
import com.anthonyeden.jtop.sentry.*;

public class Configuration{

	public Configuration(JTop parent, File file){
		this.parent = parent;
		this.file = file;
	}

	/** Return a Vector of HostConfiguration objects.
	
		@return A Vector of HostConfiguration objects
	*/

	public Vector getHosts(){
		if(hosts == null){
			hosts = new Vector();
		}
		return hosts;
	}
	
	public void load() throws Exception{
		Vector hosts = getHosts();
		hosts.removeAllElements();
	
		SAXBuilder builder = new SAXBuilder();
		Document document = builder.build(file);
		
		Element configElement = document.getRootElement();
		Namespace ns = configElement.getNamespace();
		Iterator i;
		
		// load host configuration
		i = configElement.getChildren("host", ns).iterator();
		while(i.hasNext()){
			Element hostElement = (Element)i.next();
			Host host = (Host)Class.forName(
				hostElement.getAttributeValue("type")).newInstance();
			
			host.setDisplayName(hostElement.getAttributeValue("name"));
			host.setHostname(hostElement.getChildTextTrim("hostname", ns));
			host.setPort(hostElement.getChildTextTrim("port", ns));
			
			Element sortElement = hostElement.getChild("sort", ns);
			if(sortElement != null){
				int column = Integer.parseInt(sortElement.getChildTextTrim("column", ns));
				boolean ascending = new Boolean(
					sortElement.getChildTextTrim("ascending", ns)).booleanValue();
				hosts.add(new HostConfiguration(host, column, ascending));
			} else {
				hosts.add(new HostConfiguration(host));
			}
			
			Iterator sentryIterator = hostElement.getChildren("sentry", ns).iterator();
			while(sentryIterator.hasNext()){
				Element sentryElement = (Element)sentryIterator.next();
				
				String name = sentryElement.getAttributeValue("name");
				String displayName = sentryElement.getAttributeValue("display");
				
				System.out.println("Sentry name: " + name);
				System.out.println("Display name: " + displayName);
				
				Sentry sentry = SentryManager.getInstance(name);
				sentry.setHost(host);
				sentry.setName(displayName);
				sentry.readConfiguration(sentryElement);
				host.addSentry(sentry);
			}
			
			host.setModified(false);
		}
	}
	
	public void save() throws Exception{
		XMLOutputter outputter = new XMLOutputter();
		outputter.setIndent("\t");
		outputter.setNewlines(true);
		
		Namespace ns = Namespace.getNamespace(nsPrefix, nsURL);
		Element configElement = new Element("config", ns);
		
		Enumeration hosts = parent.getHosts().list();
		while(hosts.hasMoreElements()){
			Host host = (Host)hosts.nextElement();
			Element hostElement = new Element("host", ns);
			hostElement.addAttribute("name", host.getDisplayName());
			hostElement.addAttribute("type", host.getClass().getName());
			
			Element hostnameElement = new Element("hostname", ns);
			hostnameElement.addContent(host.getHostname());
			hostElement.addContent(hostnameElement);
			
			Element portElement = new Element("port", ns);
			portElement.addContent(Integer.toString(host.getPort()));
			hostElement.addContent(portElement);
			
			Enumeration sentries = host.getSentries().list();
			while(sentries.hasMoreElements()){
				Sentry sentry = (Sentry)sentries.nextElement();
				
				Element sentryElement = new Element("sentry", ns);
				sentryElement.addAttribute("name", SentryManager.getName(sentry.getClass()));
				sentryElement.addAttribute("display", sentry.getName());
				sentry.writeConfiguration(sentryElement);
				hostElement.addContent(sentryElement);
			}
			
			HostDisplayPanel display = 
				(HostDisplayPanel)parent.getHostDisplayPanels().get(host);
			TableSorter tableSorter = display.getTableSorter();
			int sortColumn = tableSorter.getColumn();
			if(sortColumn >= 0){
				// add sorting informtation
				Element sortElement = new Element("sort", ns);
				
				Element sortColumnElement = new Element("column", ns);
				sortColumnElement.addContent(Integer.toString(sortColumn));
				sortElement.addContent(sortColumnElement);
				
				Element sortAscendingElement = new Element("ascending", ns);
				sortAscendingElement.addContent(
					new Boolean(tableSorter.isAscending()).toString());
				sortElement.addContent(sortAscendingElement);
				
				hostElement.addContent(sortElement);
			}
			
			// add the host element to the root element
			
			configElement.addContent(hostElement);
			
			host.setModified(false);
		}
		
		Document document = new Document(configElement);
		
		Writer writer = new FileWriter(file);
		outputter.output(document, writer);
		writer.close();
	}
	
	/** The XML namespace prefix used for JTop configurations. */
	
	public static final String nsPrefix = "JTop";
	
	/** The XML namespace URL used for JTop configurations. */
	
	public static final String nsURL = "http://www.anthonyeden.com/JTop";
	
	private JTop parent;
	private File file;
	private Vector hosts;

}