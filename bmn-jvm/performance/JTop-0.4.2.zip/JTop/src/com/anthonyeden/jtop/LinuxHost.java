/*-- 

 Copyright (C) 2000 Anthony Eden.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The names "J/Top" and "JTop" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact me@anthonyeden.com.
 
 4. Products derived from this software may not be called "J/Top" or "JTop", nor
    may "J/Top" or "JTop" appear in their name, without prior written permission
    from Anthony Eden (me@anthonyeden.com).
 
 In addition, I request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed by the
      Anthony Eden (http://www.anthonyeden.com/)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, 
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 POSSIBILITY OF SUCH DAMAGE.

 For more information on J/Top, please see <http://www.anthonyeden.com/projects/jtop>.
 
 */

package com.anthonyeden.jtop;

import java.io.*;
import java.net.*;
import java.util.*;
import com.anthonyeden.jtop.util.IOUtilities;

public class LinuxHost extends Host{

	public Process createProcess(){
		return new LinuxProcess();
	}

	public String[] getFieldNames(){
		return fieldNames;
	}

	public String[] getDisplayNames(){
		return displayNames;
	}
	
	public String getDisplayName(String fieldName){
		int index = getFieldIndex(fieldName);
		if(index >= 0){
			return displayNames[index];
		}
		return null;
	}
	
	public Class[] getFieldClasses(){
		return fieldClasses;
	}
	
	public Class getFieldClass(String fieldName){
		int index = getFieldIndex(fieldName);
		if(index >= 0){
			return fieldClasses[index];
		}
		return null;
	}
	
	protected int getFieldIndex(String fieldName){
		for(int i = 0; i < fieldNames.length; i++){
			if(fieldNames[i].equals(fieldName)){
				return i;
			}
		} 
		return -1;
	}
	
	public Memory getMemory(){
		if(memory == null){
			memory = new LinuxMemory(this);
		}
		return memory;
	}
	
	public void poll(){
		try{
			updating = true;
			//System.out.print("Updating...");
			Vector processes = new Vector();
			Hashtable processTable = getProcessTable();
			memory = new LinuxMemory(this);
			
			Socket s = new Socket(getHostname(), getPort());
			BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
			String line;
			int lineCount = 1;
			
			while((line = in.readLine()) != null){
				line = line.trim();
				if(line.equals("")){
					lineCount++;
					continue;
				}
			
				if(lineCount == 6){
					memory.setField("available", IOUtilities.findWord(line, 1));
					memory.setField("used", IOUtilities.findWord(line, 3));
					memory.setField("free", IOUtilities.findWord(line, 5));
					memory.setField("shared", IOUtilities.findWord(line, 7));
					memory.setField("buffered", IOUtilities.findWord(line, 9));
				} else if(lineCount == 7){
					memory.setField("swap.available", IOUtilities.findWord(line, 1));
					memory.setField("swap.used", IOUtilities.findWord(line, 3));
					memory.setField("swap.free", IOUtilities.findWord(line, 5));
					memory.setField("cached", IOUtilities.findWord(line, 7));
				} else if(lineCount >= 10){
					String pid = IOUtilities.findWord(line, 0);
					
					//System.out.println("Parsing PID: " + pid);

					LinuxProcess process = (LinuxProcess)processTable.get(pid);
					
					if(process == null){
						process = (LinuxProcess)createProcess();
						processTable.put(pid, process);
					}
					
					//process.setSystemStat(systemStat);
					process.setMemory(memory);
					process.populate(line);
					processes.addElement(process);
				}
				
				lineCount++;
			}
			
			setProcesses(processes);
		
			in.close();
			s.close();
			
			updating = false;
			
			fireHostEvent();
			
			//System.out.println("done.");
		} catch(Exception e){
			updating = false;
			e.printStackTrace();
		}
	}
	
	protected Hashtable getProcessTable(){
		if(processTable == null){
			processTable = new Hashtable();
		}
		return processTable;
	}
	
	private final String[] fieldNames = {
		"pid", "user", "priority", "nice", "size", "rss", "share", "state", "lib", "cpu", 
		"mem", "time", "command"
	}; 
		
	private static final String[] displayNames = {
		"PID", "USER", "PRI", "NI", "SIZE", "RSS", "SHARE", "STATE", "LIB", "%CPU", 
		"%MEM", "TIME", "COMMAND"
	};
	
	private static final Class[] fieldClasses = {
		Integer.class, // pid
		String.class,  // user
		Integer.class, // pri
		Integer.class, // nice
		Long.class,    // size
		Long.class,    // rss
		Double.class,  // share
		String.class,  // state
		Double.class,  // lib
		Double.class,  // cpu
		Double.class,  // mem
		String.class,  // time
		String.class   // command
	};
	
	protected LinuxMemory memory;
	
	private Hashtable processTable;

}