/*-- 

 Copyright (C) 2000 Anthony Eden.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The names "J/Top" and "JTop" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact me@anthonyeden.com.
 
 4. Products derived from this software may not be called "J/Top" or "JTop", nor
    may "J/Top" or "JTop" appear in their name, without prior written permission
    from Anthony Eden (me@anthonyeden.com).
 
 In addition, I request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed by the
      Anthony Eden (http://www.anthonyeden.com/)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, 
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 POSSIBILITY OF SUCH DAMAGE.

 For more information on J/Top, please see <http://www.anthonyeden.com/projects/jtop>.
 
 */

package com.anthonyeden.jtop.sentry;

import java.awt.Component;
import java.beans.PropertyChangeListener;
import java.util.Vector;
import org.jdom.Element;
import com.anthonyeden.jtop.Host;
import com.anthonyeden.jtop.event.*;

/** An interface which is used to test current state of a Process.

	@author Anthony Eden
*/

public interface Sentry{

	/** Get the sentry's name.
	
		@return The name
	*/

	public String getName();
	
	/** Set the sentry's name.
	
		@param name The new name
	*/
	
	public void setName(String name);
	
	/** Get the Host that this Sentry is monitoring.
	
		@return The Host
	*/
	
	public Host getHost();
	
	/** Set the Host that this Sentry is monitoring.
	
		@param host The Host
	*/
	
	public void setHost(Host host);

	/** Execute the sentry's test algorithm.  Return true if the test
		passes, false if it fails.  If the test fails, the Sentry should
		automatically call all registered Notifiers.
	
		@return True if the test passes
	*/

	public boolean test();
	
	/** Read the configuration information from the given JDOM Element.
	
		@param element The Element
	*/
	
	public void readConfiguration(Element element);
	
	/** Write the current configuration information to the given JDOM Element.
	
		@param element The Element
	*/
	
	public void writeConfiguration(Element element);
	
	/** Get a Vector of all attached notifiers.
	
		@return All notifiers
	*/
	
	public Vector getNotifiers();
	
	/** Add a notifier to the sentry.  Upon a test failure, all notifiers
		will be executed.
		
		@param notifier A Notifier
	*/
	
	public void addNotifier(Notifier notifier);
	
	/** Remove a notifier from the sentry.
		
		@param notifier A Notifier
	*/
	
	public void removeNotifier(Notifier notifier);
	
	/** Get the Sentry's editor.
	
		@return The editor An Editor
	*/
	
	public Editor getEditor();
	
	/** Get the current state of the sentry.  Possible values are:
	
		<ul>
		<li>TESTING
		<li>PASSED
		<li>FAILED
		<li>NOT_TESTED
		</ul>
		
		@return The state of the Sentry
	*/
	
	public int getState();

	public void addPropertyChangeListener(PropertyChangeListener l);
	public void removePropertyChangeListener(PropertyChangeListener l);
	
	public void addSentryListener(SentryListener l);
	public void removeSentryListener(SentryListener l);
	
	public static final int NOT_TESTED = 0;
	public static final int PASSED = 1;
	public static final int FAILED = 2;
	public static final int TESTING = 100;

}