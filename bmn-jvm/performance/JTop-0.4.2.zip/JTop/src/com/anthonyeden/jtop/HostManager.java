/*-- 

 Copyright (C) 2000 Anthony Eden.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The names "J/Top" and "JTop" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact me@anthonyeden.com.
 
 4. Products derived from this software may not be called "J/Top" or "JTop", nor
    may "J/Top" or "JTop" appear in their name, without prior written permission
    from Anthony Eden (me@anthonyeden.com).
 
 In addition, I request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed by the
      Anthony Eden (http://www.anthonyeden.com/)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, 
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 POSSIBILITY OF SUCH DAMAGE.

 For more information on J/Top, please see <http://www.anthonyeden.com/projects/jtop>.
 
 */

package com.anthonyeden.jtop;

import java.net.*;
import java.util.*;

/** This class tracks different host types which are installed.  This class 
	maintains the order in which the host type was added even though the host
	types are accessible by name.

	<p>The default installation currently supports the following host types:
	
	<ul>
	<li>Linux Direct (<code>com.anthonyeden.jtop.LinuxDirectHost</code>) - Server 
		retreives data from Linux proc file system</li>
	</ul>
	
	@author Anthony Eden
*/

public class HostManager{

	/** No-op constructor. */

	private HostManager(){
		// no op
	}
	
	/** Get a Vector of names for all registered host types.
	
		@return A Vector of names
	*/
	
	public static Vector getNames(){
		return getRegisteredHostList();
	}
	
	public static void register(String name, String className) throws 
	ClassNotFoundException{
		register(name, Class.forName(className));
	}
	
	/** Register a host type.  The display name must be a unique value, otherwise
		the existing registered host type with the same name will be replaced.
		
		@param name The display name for the host type
		@param implClass The implementation class
	*/

	public static void register(String name, Class implClass){
		Vector registeredHostList = getRegisteredHostList();
		Hashtable registeredHosts = getRegisteredHosts();
		if(!registeredHosts.contains(name)){
			registeredHostList.addElement(name);
			registeredHosts.put(name, implClass);
		}
	}
	
	/** De-register a host type.
		
		@param name The display name for the host type
	*/
	
	public static void unregister(String name){
		getRegisteredHosts().remove(name);
	}
	
	/** Create a Host implementation for the given name.
	
		@param name The host type display name
		@throws UnknownHostException Thrown if there is no registered host type
			for the given name
		@throws IllegalAccessException Thrown if the class or initializer for the
			Host is not accessible
		@throws InstantiationException Thrown if the implementation Class 
			represents an abstract class, an interface, an array class, a primitive 
			type, or void; or if the instantiation fails for some other reason.
	*/
	
	public static Host createHost(String name) throws UnknownHostException, 
	IllegalAccessException, InstantiationException{
		Class implClass = (Class)getRegisteredHosts().get(name);
		if(implClass == null){
			throw new UnknownHostException("Unknown host for name '" + name + "'");
		}
		
		return (Host)implClass.newInstance();
	}
	
	/** Get the Hashtable containing all registered host information.  This method
		should never return null.
	
		@return The registered host Hashtable
	*/
	
	protected static Hashtable getRegisteredHosts(){
		if(registeredHosts == null){
			registeredHosts = new Hashtable();
		}
		return registeredHosts;
	}
	
	/** Get a list of registered host names in the order in which they were 
		registered.
		
		@return A Vector of host type names
	*/
	
	protected static Vector getRegisteredHostList(){
		if(registeredHostList == null){
			registeredHostList = new Vector();
		}
		return registeredHostList;
	}
	
	private static Hashtable registeredHosts;
	private static Vector registeredHostList;

}