/*-- 

 Copyright (C) 2000 Anthony Eden.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The names "J/Top" and "JTop" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact me@anthonyeden.com.
 
 4. Products derived from this software may not be called "J/Top" or "JTop", nor
    may "J/Top" or "JTop" appear in their name, without prior written permission
    from Anthony Eden (me@anthonyeden.com).
 
 In addition, I request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed by the
      Anthony Eden (http://www.anthonyeden.com/)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, 
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 POSSIBILITY OF SUCH DAMAGE.

 For more information on J/Top, please see <http://www.anthonyeden.com/projects/jtop>.
 
 */

package com.anthonyeden.jtop.sentry;

import java.util.*;

public class NotifierManager{

	public static Vector getNames(){
		if(names == null){
			names = new Vector();
		}
		return names;
	}
	
	public static Class getType(String name){
		return (Class)getRegisteredNotifiers().get(name);
	}
	
	public static String getName(Class type){
		Enumeration names = getNames().elements();
		while(names.hasMoreElements()){
			String name = (String)names.nextElement();
			Class registeredType = (Class)getRegisteredNotifiers().get(name);
			if(type == registeredType){
				return name;
			}
		}
		return null;
	}

	/** Get a new instance of a Notifier which is registered with the given
		name.  If no Notifier is registered with the given name, then this
		method will return null.
		
		@param name The registered name
		@throws Exception
	*/

	public static Notifier getInstance(String name) throws Exception{
		Class c = (Class)getRegisteredNotifiers().get(name);
		if(c == null){
			return null;
		} else {
			return (Notifier)c.newInstance();
		}
	}
	
	public static void register(String name, String className) throws ClassNotFoundException{
		register(name, Class.forName(className));
	}
	
	/** Register a Notifier with the given name and implementation class.
	
		@param name The Notifier's name
		@param implClass The implementation class
	*/

	public static void register(String name, Class implClass){
		getRegisteredNotifiers().put(name, implClass);
		
		Vector names = getNames();
		if(!names.contains(name)){
			names.addElement(name);
		}
	}
	
	/** De-register a Notifier with the given name.
	
		@param name The name of the Notifier
	*/
	
	public static void deregister(String name){
		getRegisteredNotifiers().remove(name);
		
		Vector names = getNames();
		int index = names.indexOf(name);
		if(index >= 0){
			names.removeElementAt(index);
		}
	}
	
	// protected methods
	
	protected static Hashtable getRegisteredNotifiers(){
		if(registeredNotifiers == null){
			registeredNotifiers = new Hashtable();
		}
		return registeredNotifiers;
	}
	
	private static Vector names;
	private static Hashtable registeredNotifiers;

}