/*-- 

 Copyright (C) 2000 Anthony Eden.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The names "J/Top" and "JTop" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact me@anthonyeden.com.
 
 4. Products derived from this software may not be called "J/Top" or "JTop", nor
    may "J/Top" or "JTop" appear in their name, without prior written permission
    from Anthony Eden (me@anthonyeden.com).
 
 In addition, I request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed by the
      Anthony Eden (http://www.anthonyeden.com/)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, 
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 POSSIBILITY OF SUCH DAMAGE.

 For more information on J/Top, please see <http://www.anthonyeden.com/projects/jtop>.
 
 */

package com.anthonyeden.jtop;

import java.awt.*;
import javax.swing.*;
import com.anthonyeden.jtop.event.*;

public class FreeBSDMemoryDisplay extends JPanel implements HostListener{

	public FreeBSDMemoryDisplay(Host host){
		this.host = host;
		host.addHostListener(this);
		init();
	}
	
	public void responseReceived(HostEvent evt){
		FreeBSDMemory memory = (FreeBSDMemory)host.getMemory();
		//System.out.println("Memory: " + memory);
		activeMemoryField.setText(memory.getField("active").toString());
		inactiveMemoryField.setText(memory.getField("inactive").toString());
		wiredMemoryField.setText(memory.getField("wired").toString());
		cachedMemoryField.setText(memory.getField("cache").toString());
		bufferedMemoryField.setText(memory.getField("buffer").toString());
		freeMemoryField.setText(memory.getField("free").toString());
		totalSwapMemoryField.setText(memory.getField("swap.total").toString());
		freeSwapMemoryField.setText(memory.getField("swap.free").toString());
		validate();
	}
	
	private void init(){
		GridBagLayout gbl = new GridBagLayout();
		GridBagConstraints gbc = new GridBagConstraints();
		setLayout(gbl);
		
		Insets leadingLabelInsets = new Insets(2, 2, 2, 4);
		Insets defaultInsets = new Insets(2, 2, 2, 2);
		gbc.fill = GridBagConstraints.HORIZONTAL;
		
		memoryLabel = new JLabel("Memory:");
		gbc.insets = leadingLabelInsets;
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(memoryLabel, gbc);
		add(memoryLabel);
		
		gbc.insets = defaultInsets;
		
		activeMemoryLabel = new JLabel("Active:");
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(activeMemoryLabel, gbc);
		add(activeMemoryLabel);
		
		activeMemoryField = new JTextField();
		activeMemoryField.setEditable(false);
		activeMemoryField.setBorder(BorderFactory.createEmptyBorder());
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(activeMemoryField, gbc);
		add(activeMemoryField);
		
		inactiveMemoryLabel = new JLabel("Inactive:");
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(inactiveMemoryLabel, gbc);
		add(inactiveMemoryLabel);
		
		inactiveMemoryField = new JTextField();
		inactiveMemoryField.setEditable(false);
		inactiveMemoryField.setBorder(BorderFactory.createEmptyBorder());
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(inactiveMemoryField, gbc);
		add(inactiveMemoryField);
		
		wiredMemoryLabel = new JLabel("Wired:");
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(wiredMemoryLabel, gbc);
		add(wiredMemoryLabel);
		
		wiredMemoryField = new JTextField();
		wiredMemoryField.setEditable(false);
		wiredMemoryField.setBorder(BorderFactory.createEmptyBorder());
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(wiredMemoryField, gbc);
		add(wiredMemoryField);
		
		cachedMemoryLabel = new JLabel("Cached:");
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(cachedMemoryLabel, gbc);
		add(cachedMemoryLabel);
		
		cachedMemoryField = new JTextField();
		cachedMemoryField.setEditable(false);
		cachedMemoryField.setBorder(BorderFactory.createEmptyBorder());
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(cachedMemoryField, gbc);
		add(cachedMemoryField);
		
		bufferedMemoryLabel = new JLabel("Buffered:");
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(bufferedMemoryLabel, gbc);
		add(bufferedMemoryLabel);
		
		bufferedMemoryField = new JTextField();
		bufferedMemoryField.setEditable(false);
		bufferedMemoryField.setBorder(BorderFactory.createEmptyBorder());
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(bufferedMemoryField, gbc);
		add(bufferedMemoryField);
		
		freeMemoryLabel = new JLabel("Free:");
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(freeMemoryLabel, gbc);
		add(freeMemoryLabel);
		
		freeMemoryField = new JTextField();
		freeMemoryField.setEditable(false);
		freeMemoryField.setBorder(BorderFactory.createEmptyBorder());
		gbc.weightx = 1;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbl.setConstraints(freeMemoryField, gbc);
		add(freeMemoryField);
		
		swapLabel = new JLabel("Swap:");
		gbc.insets = leadingLabelInsets;
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(swapLabel, gbc);
		add(swapLabel);
		
		totalSwapMemoryLabel = new JLabel("Total:");
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(totalSwapMemoryLabel, gbc);
		add(totalSwapMemoryLabel);
		
		totalSwapMemoryField = new JTextField();
		totalSwapMemoryField.setEditable(false);
		totalSwapMemoryField.setBorder(BorderFactory.createEmptyBorder());
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(totalSwapMemoryField, gbc);
		add(totalSwapMemoryField);
		
		freeSwapMemoryLabel = new JLabel("Free:");
		gbc.weightx = 0;
		gbc.gridwidth = 1;
		gbl.setConstraints(freeSwapMemoryLabel, gbc);
		add(freeSwapMemoryLabel);
		
		freeSwapMemoryField = new JTextField();
		freeSwapMemoryField.setEditable(false);
		freeSwapMemoryField.setBorder(BorderFactory.createEmptyBorder());
		gbc.weightx = 1;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		gbl.setConstraints(freeSwapMemoryField, gbc);
		add(freeSwapMemoryField);
		
		validate();
	}
	
	private Host host;
	
	private JLabel memoryLabel;
	private JLabel activeMemoryLabel;
	private JTextField activeMemoryField;
	private JLabel inactiveMemoryLabel;
	private JTextField inactiveMemoryField;
	private JLabel wiredMemoryLabel;
	private JTextField wiredMemoryField;
	private JLabel cachedMemoryLabel;
	private JTextField cachedMemoryField;
	private JLabel bufferedMemoryLabel;
	private JTextField bufferedMemoryField;
	private JLabel freeMemoryLabel;
	private JTextField freeMemoryField;
	private JLabel swapLabel;
	private JLabel totalSwapMemoryLabel;
	private JTextField totalSwapMemoryField;
	private JLabel freeSwapMemoryLabel;
	private JTextField freeSwapMemoryField;

}