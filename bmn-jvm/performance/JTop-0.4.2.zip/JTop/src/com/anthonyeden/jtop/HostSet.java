/*-- 

 Copyright (C) 2000 Anthony Eden.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The names "J/Top" and "JTop" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact me@anthonyeden.com.
 
 4. Products derived from this software may not be called "J/Top" or "JTop", nor
    may "J/Top" or "JTop" appear in their name, without prior written permission
    from Anthony Eden (me@anthonyeden.com).
 
 In addition, I request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed by the
      Anthony Eden (http://www.anthonyeden.com/)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, 
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 POSSIBILITY OF SUCH DAMAGE.

 For more information on J/Top, please see <http://www.anthonyeden.com/projects/jtop>.
 
 */

package com.anthonyeden.jtop;

import java.util.*;
import javax.swing.*;
import javax.swing.event.*;

/** This class represents a set of Host objects.  This class implements the
	ListModel interface so it can be used in any Host list and will automatically
	reflect changes to its data structure.
	
	@author Anthony Eden
*/

public class HostSet implements ListModel{

	/** Get an Enumeration of all Hosts.
	
		@return An Enumeration of Host objects
	*/

	public Enumeration list(){
		return getHosts().elements();
	}
	
	/** Add a Host.  This method will only add the host if the host is not
		already contained in the HostSet.
		
		@param host The host to add
	*/

	public synchronized void add(Host host){
		Vector hosts = getHosts();
		int size = hosts.size();
		if(!hosts.contains(host)){
			hosts.addElement(host);
			fireIntervalAdded(size, size);
		}
	}
	
	/** Remove a Host.
		
		@param host The host to remove
	*/
	
	public synchronized void remove(Host host){
		Vector hosts = getHosts();
		int index = hosts.indexOf(host);
		if(index >= 0){
			hosts.removeElementAt(index);
			fireIntervalRemoved(index, index);
		}
	}
	
	/** Remove all Hosts. */
	
	public synchronized void clear(){
		Vector hosts = getHosts();
		int size = hosts.size();
		hosts.removeAllElements();
		fireIntervalRemoved(0, size);
	}
	
	/** Get the number of Hosts in the HostSet.
	
		@return The number of Hosts in the set
	*/

	public int getSize(){
		return getHosts().size();
	}
	
	/** Get the Host at the given index.
	
		@param index The index of the Host
		@returns The Host
	*/
	
	public Object getElementAt(int index){
		return getHosts().elementAt(index);
	}
	
	/** Add a ListDataListener.
	
		@param l The ListDataListener
	*/
	
	public void addListDataListener(ListDataListener l){
		getListDataListeners().addElement(l);
	}
	
	/** Remove a ListDataListener.
	
		@param l The ListDataListener
	*/
	
	public void removeListDataListener(ListDataListener l){
		getListDataListeners().removeElement(l);
	}
	
	// protected methods
	
	/** Get a Vector of all Hosts in the set.  The HostSet class delegates all
		calls to this Vector.  This method should never return null.
	
		@return A Vector of Host objects
	*/
	
	protected Vector getHosts(){
		if(hosts == null){
			hosts = new Vector();
		}
		return hosts;
	}
	
	/** Get a Vector of registered ListDataListeners.  This method should
		never return null.
		
		@return A Vector of ListDataListeners
	*/
	
	protected Vector getListDataListeners(){
		if(listDataListeners == null){
			listDataListeners = new Vector();
		}
		return listDataListeners;
	}
	
	protected void fireIntervalAdded(int start, int end){
		ListDataEvent evt = new ListDataEvent(this, ListDataEvent.INTERVAL_ADDED, 
			start, end);
		Vector v;
		
		synchronized(this){
			v = (Vector)(getListDataListeners().clone());
		}
		
		Enumeration l = v.elements();
		while(l.hasMoreElements()){
			((ListDataListener)l.nextElement()).intervalAdded(evt);
		}
	}
	
	protected void fireIntervalRemoved(int start, int end){
		ListDataEvent evt = new ListDataEvent(this, ListDataEvent.INTERVAL_REMOVED, 
			start, end);
		Vector v;
		
		synchronized(this){
			v = (Vector)(getListDataListeners().clone());
		}
		
		Enumeration l = v.elements();
		while(l.hasMoreElements()){
			((ListDataListener)l.nextElement()).intervalRemoved(evt);
		}
	}
	
	private Vector hosts;
	private Vector listDataListeners;

}