/*-- 

 Copyright (C) 2000 Anthony Eden.
 All rights reserved.
 
 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions
 are met:
 
 1. Redistributions of source code must retain the above copyright
    notice, this list of conditions, and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright
    notice, this list of conditions, and the disclaimer that follows 
    these conditions in the documentation and/or other materials 
    provided with the distribution.

 3. The names "J/Top" and "JTop" must not be used to endorse or promote products
    derived from this software without prior written permission.  For
    written permission, please contact me@anthonyeden.com.
 
 4. Products derived from this software may not be called "J/Top" or "JTop", nor
    may "J/Top" or "JTop" appear in their name, without prior written permission
    from Anthony Eden (me@anthonyeden.com).
 
 In addition, I request (but do not require) that you include in the 
 end-user documentation provided with the redistribution and/or in the 
 software itself an acknowledgement equivalent to the following:
     "This product includes software developed by the
      Anthony Eden (http://www.anthonyeden.com/)."

 THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR(S) BE LIABLE FOR ANY DIRECT, 
 INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR 
 SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
 HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, 
 STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING 
 IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 POSSIBILITY OF SUCH DAMAGE.

 For more information on J/Top, please see <http://www.anthonyeden.com/projects/jtop>.
 
 */

package com.anthonyeden.jtop;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import org.jdom.*;
import org.jdom.input.*;
import org.jdom.output.*;
import com.anthonyeden.jtop.event.*;
import com.anthonyeden.jtop.sentry.*;
import com.anthonyeden.jtop.actions.*;

/** JTop is a Java version of the UNIX top application with many additional features.
	
	<ul>
	<li>View top output from multiple hosts</li>
	<li>Load and save configuration to XML</li>
	</ul>
	
	@author Anthony Eden
*/

public class JTop extends JFrame{

	/** Default constructor. */

	public JTop(){
		try{
			loadSystemConfiguration();
		} catch(Exception e){
			error(e);
		}
	
		init();
		
		try{
			loadConfiguration();
		} catch(Exception e){
			error(e);
		}
	}
	
	/** Main method used to start JTop.  No command line arguments
		are supported at this time.
		
		@param args An array of command line arguments
	*/
	
	public static void main(String[] args){
		//HostManager.register("Linux Direct", LinuxDirectHost.class);
		//HostManager.register("Free BSD", FreeBSDHost.class);
	
		JTop app = new JTop();
		app.show();
	}
	
	public static void error(String message){
		error(message, null);
	}
	
	/** Method which displays the message part of the given Throwable
		in a dialog.
		
		@param t The Throwable
	*/
	
	public static void error(Throwable t){
		error(t.getMessage(), t);
	}
	
	/** Method which displays the given message in a dialog.
		
		@param t The Throwable
	*/
	
	public static void error(String message, Throwable t){
		if(t != null){
			t.printStackTrace(System.err);
		}
		
		JOptionPane.showMessageDialog(null, message,
			"Error", JOptionPane.ERROR_MESSAGE);
	}
	
	public static NotifierSet getNotifiers(){
		if(notifiers == null){
			notifiers = new NotifierSet();
		}
		return notifiers;
	}
	
	public static void addNotifier(Notifier notifier){
		getNotifiers().add(notifier);
	}
	
	/** Get the last directory that was used when opening or saving a
		configuration.
		
		@return The last open directory
	*/
	
	public File getLastDirectory(){
		if(lastDirectory == null){
			lastDirectory = new File(System.getProperty("user.dir"));
		}
		return lastDirectory;
	}
	
	/** Set the last directory that was used when opening or saving a
		configuration.
		
		@param lastDirectory The last open directory
	*/
	
	public void setLastDirectory(File lastDirectory){
		this.lastDirectory = lastDirectory;
	}
	
	/** Add the host to the tab list with no initial sorting.
	
		@param host The host to add
	*/
	
	public void add(Host host){
		add(host, -1, true);
	}
	
	/** Add the host to the tab list with the initial sorting values.
	
		@param host The host to add
		@param column The column to sort
		@param ascending True if the sort is in ascending order
	*/
	
	public void add(Host host, int column, boolean ascending){
		HostDisplayPanel hostDisplayPanel = new HostDisplayPanel(host);
		tabbedPane.addTab(host.getDisplayName(), null, hostDisplayPanel, 
			host.getHostname());
		getHosts().add(host);
		getHostDisplayPanels().put(host, hostDisplayPanel);
		hostDisplayPanel.sort(column, ascending);
		modified = true;
	}
	
	/** Display a dialog for adding a new host. */
	
	public void addHost(){
		HostDialog dialog = new HostDialog(this);
		dialog.addDialogListener(new HostDialogListener(this));
		dialog.setTitle("New Host");
		dialog.show();
	}
	
	/** Configure the currently selected host. */
	
	public void configureHost(){
		Host host = getSelectedHost();
		if(host != null){
			editHost(host);
		}
	}
	
	/** Get the currently selected host.
	
		@return The current selected Host
	*/
	
	public Host getSelectedHost(){
		int tabIndex = tabbedPane.getSelectedIndex();
		if(tabIndex >= 0){
			HostSet hosts = getHosts();
			return (Host)hosts.getElementAt(tabIndex);
		} else {
			return null;
		}
	}
	
	/** Remove the currently selected host. */
	
	public void removeHost(){
		Host host = getSelectedHost();
		if(host == null){
			return;
		}
		
		int tabIndex = tabbedPane.getSelectedIndex();
		int result = JOptionPane.showConfirmDialog(null, "Really remove host " + 
			host.getDisplayName() + "?", "Are You Sure?", JOptionPane.OK_CANCEL_OPTION, 
			JOptionPane.WARNING_MESSAGE);
		if(result == JOptionPane.OK_OPTION){
			host.stopPolling();
			tabbedPane.removeTabAt(tabIndex);
			hosts.remove(host);
			getHostDisplayPanels().remove(host);
			modified = true;
		}
	}
	
	/** Remove all hosts. */
	
	public void clearHosts(){
		tabbedPane.removeAll();
		
		Enumeration hosts = getHosts().list();
		while(hosts.hasMoreElements()){
			Host host = (Host)hosts.nextElement();
			host.stopPolling();
		}
		
		getHosts().clear();
		getHostDisplayPanels().clear();
		modified = true;
	}
	
	/** Edit the given Host.
	
		@param host The Host to edit
	*/
	
	public void editHost(Host host){
		HostDialog dialog = new HostDialog(this, host);
		dialog.setTitle("Configure Host");
		dialog.show();
	}
	
	/** Clear all hosts as well as the reference to the current
		configuration file.
	*/
	
	public void newConfiguration(){
		if(!optionSave()){
			return;
		}
		
		clearHosts();
		configuration = null;
		modified = false;
	}
	
	/** If the current configuration is modified, then this method
		should display a dialog asking the user if they would like to
		save the current configuration.  A return value of true means that
		the caller should continue processing.  A return value of false
		means that caller should NOT continue processing.
		
		@return True to continue processing
	*/
	
	protected boolean optionSave(){
		if(isModified()){
			Object[] options = {"Save", "Don't Save", "Cancel"};
			int result = JOptionPane.showOptionDialog(null, "Your current configuration " + 
				"has been modified.\n  Would you like to save your current configuration?",
				"Save Current Configuration?", JOptionPane.DEFAULT_OPTION, 
				JOptionPane.WARNING_MESSAGE, null, options, options[0]);
				
			switch(result){
				case 0:
					save();
					return true;
				case 1:
					return true;
				case 2:
					return false;
				default:
					return false;
			}
		} else {
			return true;
		}
	}
	
	/** Display a file chooser to select the configuration file to
		open.
	*/
	
	public void open(){
		if(!optionSave()){
			return;
		}
	
		JFileChooser fileChooser = new JFileChooser(getLastDirectory());
		int result = fileChooser.showOpenDialog(null);
		setLastDirectory(fileChooser.getCurrentDirectory());
		if(result == JFileChooser.APPROVE_OPTION){
			open(fileChooser.getSelectedFile());
		}
	}
	
	/** Open the given configuration file.
	
		@param file The configuration File
	*/
	
	public void open(File file){
		if(!optionSave()){
			return;
		}
	
		try{
			Configuration configuration = new Configuration(this, file);
			loadConfiguration(configuration);
		} catch(Exception e){
			error(e);
		}
	}
	
	/** Save the current configuration.  If the current configuration was 
		loaded from a file, then save back to the same file.  If the current 
		configuration is not associated with any file, then call the 
		<code>saveAs()</code> method.
	*/
	
	public void save(){
		if(configuration == null){
			saveAs();
		} else {
			try{
				saveConfiguration();
			} catch(Exception e){
				error(e);
			}
		}
	}
	
	/** Display a file chooser for selecting the file to use for storing
		the current configuration.
	*/
	
	public void saveAs(){
		JFileChooser fileChooser = new JFileChooser(getLastDirectory());
		int result = fileChooser.showSaveDialog(null);
		setLastDirectory(fileChooser.getCurrentDirectory());
		if(result == JFileChooser.APPROVE_OPTION){
			try{
				File file = fileChooser.getSelectedFile();
				Configuration c = new Configuration(this, file);
				saveConfiguration(c);
			} catch(Exception e){
				error(e);
			}
		}
	}
	
	/** Show the application preferences dialog. */
	
	public void showPreferencesDialog(){
	
	}
	
	/** Show the sentries dialog for the current Host. */
	
	public void showSentriesDialog(){
		showSentriesDialog(getSelectedHost());
	}
	
	/** Show the sentries dialog for the given Host.
	
		@param host The Host to show
	*/
	
	public void showSentriesDialog(Host host){
		if(host == null){
			error("Please select a host.");
			return;
		}
		
		SentriesDialog d = new SentriesDialog(this, host);
		d.show();
	}
	
	public void showAllSentriesDialog(){
		AllSentriesDialog d = new AllSentriesDialog(this);
		d.show();
	}
	
	public void showNotifiersDialog(){
		NotifiersDialog d = new NotifiersDialog(this);
		d.show();
	}
	
	/** Quit the JTop application. */
	
	public void quit(){
		if(!optionSave()){
			return;
		}
	
		System.exit(0);
	}
	
	/** Get a Hashtable of actions.
	
		@return A Hashtable of actions
	*/
	
	public Hashtable getActions(){
		if(actions == null){
			actions = new Hashtable();
			actions.put("file.new", new NewAction(this));
			actions.put("file.open", new OpenAction(this));
			actions.put("file.save", new SaveAction(this));
			actions.put("file.saveAs", new SaveAsAction(this));
			actions.put("file.quit", new QuitAction(this));
			
			actions.put("edit.cut", new CutAction(this));
			actions.put("edit.copy", new CopyAction(this));
			actions.put("edit.paste", new PasteAction(this));
			actions.put("edit.preferences", new PreferencesAction(this));
			
			actions.put("host.add", new AddHostAction(this));
			actions.put("host.configure", new ConfigureHostAction(this));
			actions.put("host.remove", new RemoveHostAction(this));
			actions.put("host.sentries", new SentriesAction(this));
			actions.put("host.notifiers", new NotifiersAction(this));
			
			actions.put("help.usersGuide", new UsersGuideAction());
		}
		return actions;
	}
	
	/** Sort the currently selected host processes on the given column.
	
		@param column The column to sort on
	*/
	
	public void sort(int column){
		Host host = getSelectedHost();
		if(host != null){
			HostDisplayPanel display = (HostDisplayPanel)getHostDisplayPanels().get(host);
			display.sort(column);
			modified = true;
		}
	}
	
	/** Filter the currently selected host.  Match only rows where the given column
		has the given value.
		
		@param column The column
		@param value The value
	*/
	
	public void filter(int column, Object value){
		Host host = getSelectedHost();
		if(host != null){
			HostDisplayPanel display = (HostDisplayPanel)getHostDisplayPanels().get(host);
			display.filter(column, value);
			modified = true;
		}
	}
	
	/** Return a Vector of hosts in the current configuration.  This method should
		never return null.
	
		@return A Vector of Host objects
	*/
	
	public HostSet getHosts(){
		if(hosts == null){
			hosts = new HostSet();
		}
		return hosts;
	}
	
	/** Return a Hashtable of HostDisplayPanels in the current configuration.  
		This method should never return null.
	
		@return A Vector of Host objects
	*/
	
	public Hashtable getHostDisplayPanels(){
		if(hostDisplayPanels == null){
			hostDisplayPanels = new Hashtable();
		}
		return hostDisplayPanels;
	}
	
	public boolean isModified(){
		if(modified){
			return modified;
		} else {
			Enumeration hosts = getHosts().list();
			while(hosts.hasMoreElements()){
				if(((Host)hosts.nextElement()).isModified()){
					return true;
				}
			}
		}
		return false;
	}
	
	public void setModified(boolean modified){
		this.modified = modified;
	}
	
	// protected methods
	
	/** Load the system configuration.
	
		@throws Exception
	*/
	
	protected void loadSystemConfiguration() throws Exception{
		File file = new File(SYSTEM_CONFIG_PATH);
		if(file.exists()){
			systemConfiguration = new SystemConfiguration(this, file);
			systemConfiguration.load();
		}
	}
	
	/** Load the default configuration which should be located in the current
		working directory with the name <code>config.xml</code>.
		
		@throws Exception
	*/
	
	protected void loadConfiguration() throws Exception{
		File file = new File(CONFIG_PATH);
		if(file.exists()){
			Configuration configuration = new Configuration(this, file);
			loadConfiguration(configuration);
		}
	}
	
	/** Load the configuration from the given file.
	
		@param file The file to load from
		@throws Exception
	*/
	
	protected void loadConfiguration(Configuration configuration) throws Exception{
		clearHosts();

		configuration.load();
		
		Enumeration hosts = configuration.getHosts().elements();
		while(hosts.hasMoreElements()){
			HostConfiguration hostConfig = (HostConfiguration)hosts.nextElement();
			Host host = hostConfig.getHost();
			add(host, hostConfig.getColumn(), hostConfig.isAscending());
			host.startPolling();
		}
		
		this.configuration = configuration;
		modified = false;
	}
	
	protected void saveConfiguration() throws Exception{
		saveConfiguration(configuration);
	}
	
	/** Save the given configuration .
	
		@param configuration The configuration to save
		@throws Exception
	*/
	
	protected void saveConfiguration(Configuration configuration) throws Exception{
		configuration.save();
		this.configuration = configuration;
		modified = false;
	}
	
	// private methods
	
	/** Initialize the user interface. */
	
	private void init(){
		tabbedPane = new JTabbedPane();
		tabbedPane.addMouseListener(new MouseAdapter(){
			public void mouseReleased(MouseEvent evt){
				int selectedTab = tabbedPane.getSelectedIndex();
				if(evt.isPopupTrigger()){
					TabPopupMenu popupMenu = new TabPopupMenu(JTop.this);
					popupMenu.show(tabbedPane, evt.getX(), evt.getY());
				}
			}
			
			public void mouseClicked(MouseEvent evt){
				int selectedTab = tabbedPane.getSelectedIndex();
				if(evt.getClickCount() >= 2){
					configureHost();
				}
			}
		});
		
		tabbedPane.addKeyListener(new KeyAdapter(){
			public void keyReleased(KeyEvent evt){
				switch(evt.getKeyCode()){
					case KeyEvent.VK_DELETE:
						removeHost();
						break;
					case KeyEvent.VK_I:
						sort(0);
						break;
					case KeyEvent.VK_U:
						sort(1);
						break;
					case KeyEvent.VK_P:
						sort(3);
						break;
					case KeyEvent.VK_M:
						sort(8);
						break;
					case KeyEvent.VK_C:
						sort(7);
						break;
					case KeyEvent.VK_D:
						sort(9);
						break;
					default:
						break;
				}
			}
		});
		
		toolBar = new JTopToolBar(this);
	
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(tabbedPane, "Center");
		getContentPane().add(toolBar, "North");
		
		menuBar = new JTopMenuBar(this);
		setJMenuBar(menuBar);
		
		setTitle(TITLE);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		setSize((int)(screenSize.width * .8), (int)(screenSize.height * .8));
	}
	
	class HostDialogListener implements DialogListener{
		
		public HostDialogListener(JTop parent){
			this.parent = parent;
		}
	
		public void dialogClosed(DialogEvent evt){
			if(evt.getAction().equals("approve")){
				Host host = (Host)evt.getTarget();
				parent.add(host);
				host.startPolling();
			}
		}
		
		private JTop parent;
	
	}
	
	public static final String TITLE = "J/Top";
	public static final String SYSTEM_CONFIG_PATH = "../sysconfig.xml";
	public static final String CONFIG_PATH = "../config.xml";

	public static boolean debuggingAllowed = false;
	public static boolean debug = false;
	
	private static NotifierSet notifiers;

	private boolean modified = false;
	
	private File lastDirectory;
	private SystemConfiguration systemConfiguration;
	private Configuration configuration;
	private JTabbedPane tabbedPane;
	private JTopToolBar toolBar;
	private JTopMenuBar menuBar;
	private Hashtable actions;
	private Hashtable hostDisplayPanels;
	private HostSet hosts;

}