#!/usr/bin/perl

$procdir = "/proc";
%owner_table;

sub printdata {

print "--- system stat ---\n";

# read system stat

$sysstat = "$procdir/stat";
open(SYSTEM_STAT, $sysstat) || die("Error: Cannot open $sysstat.\n");
while(<SYSTEM_STAT>){
	print $_;
}

print "--- memory ---\n";

$mem = "$procdir/meminfo";
open(MEMORY, $mem) || die("Error: Cannot open $mem.\n");
while(<MEMORY>){
	print $_;
}

print "--- process stat ---\n";

@ls = split(/\n/, `ls -l $procdir`);
foreach $ls (@ls){
	if($ls =~ /^d/ && $ls =~ /\d+$/){
		($flags,$sub,$owner,$grp,$size,$month,$day,$time,$name) =
split(/\s+/, $ls);
		$owner_table{$name} = $owner;
	}
}

opendir(PROC, $procdir);
@files = readdir(PROC);

foreach $file (@files){
	if($file =~ /^\d+$/){
		$cmdfile = "$procdir/$file/cmdline";
		open(CMDFILE, $cmdfile) || die("Error: Cannot open
$cmdfile.\n");
		$cmdline = <CMDFILE>;
		close(CMDFILE);

		$statfile = "$procdir/$file/stat";
		open(STATFILE, $statfile) || die("Error: Cannot open
$statfile.\n");
		while($statdata = <STATFILE>){
			chomp($statdata);
			print "$owner_table{$file} $statdata $cmdline\n";
		}
		close(STATFILE);
	}
}

}

return 1;
