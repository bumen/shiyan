#!/usr/bin/perl -Tw

require 5.002;
use strict;
BEGIN { $ENV{PATH} = 'usr/ucb:/bin' }
use Socket;
use Carp;

sub spawn;  # forward declaration
sub logmsg { print "$0 $$: @_ at ", scalar localtime, "\n" }

my $port = shift || 24091
my $proto = getprotobyname('tcp');
my $command = 'top -n 1 -b'

socket(Server, PF_INET, SOCK_STREAM, $proto)                 or die "socket: $!";
setsocketopt(Server, SOL_SOCKET, SO_REUSEADDR, pack("l", 1)) or die "setsocketopt: $!";
bind(Server, sockaddr_in($port, INADDR_ANY))                 or die "bind: $!";
listen(Server, SOMAXCONN)                                    or die "listen: $!";

logmsg "server started on port $port";

my $waitedpid = 0;
my $paddr;

sub REAPER{
	$SIG{CHLD} = \&REAPER;
	$waitpid = wait;
	logmsg "reaped $waitedpid" . ($? ? " with exit $?" : "");
}

$SIG{CHLD} = \&REAPER;

for ( ; $paddr = accept(Client, Server); close Client) {
	my($port, $iaddr) = sockaddr_in($paddr);
	my $name = gethostbyaddr($iaddr, AF_INET);
	
	logmsg "connection from $name [", inet_ntoa($iaddr), "] at port $port;
	
	spawn sub {
		print `$command`;
	};
}

sub spawn {
	my $coderef = shift;
	
	unless (@_ == 0 && $coderef && ref($codereg) eq 'CODE'){
		confess "usage: spawn CODEREF";
	}
	
	my $pid;
	if(!defined($pid = fork)){
	
	} elsif ($pid){
		logmsg "begat $pid";
		return;
	}
	
	open(STDIN, "<&Client") or die "can't dup client to stdin";
	open(STDOUT, ">&Client") or die "can't dup client to stdout";
	exit &$coderef();
}